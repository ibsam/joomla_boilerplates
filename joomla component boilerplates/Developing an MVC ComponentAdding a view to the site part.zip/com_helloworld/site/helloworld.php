<?php 
echo "hello every one"
;?>
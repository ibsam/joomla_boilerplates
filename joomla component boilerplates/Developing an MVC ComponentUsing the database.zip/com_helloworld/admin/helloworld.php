<?php 
echo "hello Admin"
;?>